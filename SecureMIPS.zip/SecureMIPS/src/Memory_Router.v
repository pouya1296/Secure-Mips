module Memory_Router (
    input [31:0] cpu_inst_addr,
    output reg [31:0] cpu_inst_in,
    
    input [31:0] cpu_data_addr,
    input [31:0] cpu_data_out_to_mem,
    input cpu_mem_read, 
    input cpu_mem_write, 
    output reg [31:0] cpu_data_in_from_mem,
    
    input mode_bit,

    output reg hash_write_en, 
    output reg hash_read_en,
    input [31:0] hash_data_in,

    output reg ram_write_en, 
    output reg ram_read_en,
    output [31:0] ram_data_in,
    input [31:0] ram_data_out,
    input [31:0] ram_inst_data_out,

    output reg rom_read_en,
    input [31:0] rom_data_out
);

    assign ram_data_in = cpu_data_out_to_mem;


    always @(*) begin
        cpu_inst_in = 32'b0;
        rom_read_en = 1'b0;

        if (cpu_inst_addr >= 32'h0000 && cpu_inst_addr <= 32'h0FFF) begin
            if (mode_bit == 1'b1) begin
                rom_read_en = 1'b1;
                cpu_inst_in = rom_data_out;
            end
        end
        else if (cpu_inst_addr >= 32'h1000 && cpu_inst_addr <= 32'h1FFF) begin
            cpu_inst_in = ram_inst_data_out; 
        end
    end


    always @(*) begin
        hash_write_en = 0;
        hash_read_en = 0;
        ram_write_en = 0;
        ram_read_en = 0;
        cpu_data_in_from_mem = 32'b0;

        if (cpu_data_addr >= 32'h1000 && cpu_data_addr <= 32'h1FFF) begin
            ram_read_en = cpu_mem_read;
            ram_write_en = cpu_mem_write;
            if (cpu_mem_read) begin
                cpu_data_in_from_mem = ram_data_out;
            end
        end

        else if (cpu_data_addr >= 32'h2000 && cpu_data_addr <= 32'h20FF) begin
            if (mode_bit == 1'b1) begin
                hash_read_en = cpu_mem_read;
                hash_write_en = cpu_mem_write;
                if (cpu_mem_read) begin
                    cpu_data_in_from_mem = hash_data_in;
                end
            end
        end
        
    end

endmodule