`timescale 1ns / 1ps

module tb_main;

    // سیگنال‌های کلاک و ریست
    reg clk;
    reg rst;

    // فراخوانی ماژول اصلی پروژه
    main uut (
        .clk(clk),
        .rst(rst)
    );

    // تولید کلاک با دوره تناوب 10 نانوثانیه
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // ایجاد فایل VCD برای مشاهده شکل‌موج‌ها در GTKWave
    initial begin
        $dumpfile("dump.vcd"); // نام فایل دقیقا مطابق با runner.sh
        $dumpvars(0, tb_main);
    end

    // فرآیند تست سناریوها
    initial begin
        $display("==================================================");
        $display("Starting Secure MIPS Verification...");
        $display("==================================================");

        // =========================================================
        // سناریوی اول: اجرای موفق (Valid Boot)
        // =========================================================
        $display("\n[Scenario 1] Testing Valid Boot...");
        
        // بارگذاری برنامه‌ها در حافظه‌های main.v
        $readmemh("boot.hex", uut.boot_rom);
        $readmemh("user_valid.hex", uut.user_ram);

        // اعمال ریست
        rst = 1;
        #20;
        rst = 0;

        // صبر برای تغییر Mode_Bit به 0 (ورود به User Mode)
        fork
            begin
                wait(uut.core.current_mode == 1'b0);
                $display("[SUCCESS] Bootloader verified the hash.");
                $display("[SUCCESS] DROP_PRIV executed. Switched to User Mode.");
            end
            begin
                #100000; // تایم‌اوت 100,000 نانوثانیه برای پردازش 4KB رم
                if (uut.core.current_mode !== 1'b0) begin
                    $display("[FAIL] Scenario 1 Timed out! CPU stuck in Secure Mode.");
                end
            end
        join_any
        disable fork;

        #200; // اجرای چند کلاک از برنامه کاربر

        // =========================================================
        // سناریوی دوم: برنامه دستکاری شده (Tampered Program)
        // =========================================================
        $display("\n[Scenario 2] Testing Tampered Program...");
        
        // لود کردن برنامه مخرب در RAM
        $readmemh("user_tampered.hex", uut.user_ram);

        // ریست مجدد سیستم
        rst = 1;
        #20;
        rst = 0;

        // زمان کافی برای اجرای حلقه هش
        #100000; // اصلاح شده به 100,000 نانوثانیه

        // بررسی وضعیت Mode_Bit (باید 1 باقی مانده باشد)
        if (uut.core.current_mode == 1'b1) begin
            $display("[SUCCESS] Tampered code detected. Hash mismatch!");
            $display("[SUCCESS] CPU remained in Secure Mode.");
        end else begin
            $display("[FAIL] Security Breach! CPU incorrectly entered User Mode.");
        end

        // =========================================================
        // سناریوی سوم: تست Hardware Execution Watchdog
        // =========================================================
        $display("\n[Scenario 3] Testing Watchdog Reset...");
        
        // برای تست واچ‌داگ، PC را دستی به محدوده غیرمجاز رم (0x1000) می‌بریم
        force uut.core.pc = 32'h00001004;
        #20;
        
        if (uut.watchdog_rst == 1'b1) begin
            $display("[SUCCESS] Watchdog triggered system reset upon illegal RAM access.");
        end else begin
            $display("[FAIL] Watchdog failed to detect illegal RAM access.");
        end
        release uut.core.pc;

        // =========================================================
        // پایان شبیه‌سازی
        // =========================================================
        $display("\n==================================================");
        $display("Verification Completed.");
        $display("==================================================");
        $finish;
    end

    // مانیتور کردن سیگنال‌ها برای عیب‌یابی
    initial begin
        // این خط کامنت شده تا خروجی ترمینال با هزاران خط پر نشود.
        // برای دیباگ دقیق از GTKWave استفاده کنید.
        // $monitor("Time=%0t | PC=%h | Mode=%b | Watchdog_RST=%b", $time, uut.core.pc, uut.core.current_mode, uut.watchdog_rst);
    end

    // ---------------------------------------------------------
    // DIAGNOSTIC METRICS PRINTER
    // ---------------------------------------------------------
    always @(posedge clk) begin
        // The bne instruction in verify_hash is located at PC = 0x2C
        // We will print the metrics exactly when the CPU reaches this line.
        if (uut.core.pc == 32'h00000030) begin
            $display("\n================ METRICS REPORT ================");
            $display("Time: %0t", $time);
            $display("RAM Ptr ($s0) reached: %h", uut.core.regfile[16]);
            $display("Expected Limit ($s1) : %h", uut.core.regfile[17]);
            $display("------------------------------------------------");
            $display("EXPECTED HASH ($s3)  : %h", uut.core.regfile[19]);
            $display("ACTUAL COMPUTED ($t1): %h", uut.core.regfile[9]);
            $display("================================================\n");
        end
    end
endmodule