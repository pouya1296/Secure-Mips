.text
main:
    addi $t0, $zero, 5
    addi $t1, $zero, 10
    add  $t2, $t0, $t1 

end_loop:
    j end_loop