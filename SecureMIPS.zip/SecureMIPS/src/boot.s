# 1. Initialize Pointers
    addi $s0, $zero, 0x1000   # $s0 = RAM Start (0x1000)
    addi $s1, $zero, 0x2000   # $s1 = RAM End Limit (0x2000)
    addi $s2, $zero, 0x2000   # $s2 = Crypto Accelerator Address

    # 2. Build the 32-bit Expected Hash (0x0908502c)
    ori  $s3, $zero, 0x0908   # Step 1: Load upper bits -> $s3 = 0x00000908
    sll  $s3, $s3, 16         # Step 2: Shift them up   -> $s3 = 0x09080000
    ori  $s3, $s3, 0x502c     # Step 3: Load lower bits -> $s3 = 0x0908502c

    # 3. Hash Calculation Loop
hash_loop:
    beq  $s0, $s1, verify_hash  # If we reached 0x2000, verify the hash
    lw   $t0, 0($s0)            # Read word from User RAM
    sw   $t0, 0($s2)            # Write word to Hash Accelerator
    addi $s0, $s0, 4            # Increment RAM pointer
    j    hash_loop              # Loop

    # 4. Verification
verify_hash:
    lw   $t1, 0($s2)            # Read the final computed hash
    bne  $t1, $s3, boot_fail    # If hash doesn't match, lock down

    # 5. Success - Drop Privileges & Jump
    DROP_PRIV                   # Change Mode_Bit to 0
    j    0x1000                 # Jump to User RAM

    # 6. Fail - Infinite Loop
boot_fail:
    j    boot_fail              # System halted in Secure Mode