#!/bin/bash
#
# Usage:
# ./script_ubuntu.sh "top_module_name"
#
# This script automatically compiles a Verilog testbench, runs the simulation,
# and opens GTKWave to view the waveform if not already running.
#
# Change `default_top_module` and other parameters if needed.
#
# Requirements for the Verilog testbench code:
# 1) `$dumpvars` must be used on the first line of the `initial` block.
# 2) `$finish` must be used on the last line of the same `initial` block.

default_top_module="tb"
vcd_file="dump.vcd"


top_module=${1:-$default_top_module}
current_dir=$(pwd)

if [ ! -d "build" ]; then
    mkdir -p "build"
fi

find "$current_dir" -name "*.v" > build/filelist.txt

cd build || exit 1
cp ../*.hex . 2>/dev/null
# Compile
iverilog -g2012 -s $top_module -o build.out -f filelist.txt
if [ $? -ne 0 ]; then
    echo "***** Error in Compilation *****"
    echo
    exit 1
fi

# Simulate
vvp build.out
if [ $? -ne 0 ]; then
    echo "***** Error in Simulation *****"
    echo
    exit 1
fi

# Handle GTKWave
if pgrep -x "gtkwave" >/dev/null; then
    echo "***** OK and GTK is running *****"
    echo
    exit 0
else
    gtkwave "$vcd_file" &>/dev/null &
    if [ $? -ne 0 ]; then
        echo "***** Error in Waveform *****"
        echo
        exit 1
    fi
    exit 0
fi
