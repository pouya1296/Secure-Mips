module Hash_Accelerator (
    input wire clk,
    input wire rst,
    input wire [31:0] data_in,
    input wire write_en,
    input wire read_en,
    output reg [31:0] data_out
);

    reg [31:0] hash_reg;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            hash_reg <= 32'b0;
        end else if (write_en) begin
            hash_reg <= hash_reg ^ data_in;
        end
    end

    always @(*) begin
        if (read_en) begin
            data_out = hash_reg;
        end else begin
            data_out = 32'b0; 
        end
    end

endmodule