module CPU (
    input clk, 
    input rst,
    output [31:0] inst_addr,
    input [31:0] inst_in,
    output  [31:0] data_addr,
    output wire [31:0] data_out,
    input  [31:0] data_in,
    output reg mem_read,
    output reg mem_write,
    output current_mode
);

    reg mode_bit;
    assign current_mode = mode_bit;

    reg [31:0] pc;
    assign inst_addr = pc; 

    wire [15:0] pre_imm = inst_in[15:0];
    wire [4:0] pre_rs = inst_in[25:21];
    wire [4:0] pre_rt = inst_in[20:16];
    assign data_addr = regfile[pre_rs] + {{16{pre_imm[15]}}, pre_imm};
    assign data_out = regfile[pre_rt];

    assign mem_read = (inst_in[31:26] == 6'b100011);
    assign mem_write = (inst_in[31:26] == 6'b101011);

    reg [31:0] inst_temp;
    reg [4:0] inst_rs, inst_rt, inst_rd;
    reg [31:0] val_rs, val_rt;
    reg [15:0] inst_imm;
    reg [31:0] inst_imm_sext;
    reg [31:0] inst_imm_zext; 
    reg [31:0] regfile[32];
    reg [31:0] reghi, reglo;

    task write2reg(input [4:0] reg_dest, input [31:0] val);
        begin
            if (reg_dest !== 5'd0) regfile[reg_dest] = val;
        end
    endtask

    task exec_internal;
        begin
            inst_temp = inst_in; 
            pc = pc + 4;

            inst_rs = inst_temp[25:21];
            inst_rt = inst_temp[20:16];
            inst_rd = inst_temp[15:11];
            inst_imm = inst_temp[15:0];
            
            inst_imm_sext = {{16{inst_imm[15]}}, inst_imm};
            inst_imm_zext = {16'b0, inst_imm};
            
            val_rs = regfile[inst_rs];
            val_rt = regfile[inst_rt];

            case (inst_temp[31:26])
                6'b000000: begin  // RType
                    case (inst_temp[5:0])
                        6'b100000: write2reg(inst_rd, val_rs + val_rt);  // add
                        6'b100010: write2reg(inst_rd, val_rs - val_rt);  // sub
                        6'b100100: write2reg(inst_rd, val_rs & val_rt);  // and
                        6'b100101: write2reg(inst_rd, val_rs | val_rt);  // or
                        6'b100110: write2reg(inst_rd, val_rs ^ val_rt);  // xor
                        6'b101010: write2reg(inst_rd, val_rs < val_rt ? 1 : 0);  // slt
                        6'b000100: write2reg(inst_rd, val_rs << val_rt[4:0]);  // sll
                        6'b000110: write2reg(inst_rd, val_rs >> val_rt[4:0]);  // srl
                        6'b001000: pc = val_rs; // jr
                        6'b000000: write2reg(inst_rd, val_rt << inst_temp[10:6]);  // sll (imm)
                        6'b011010: begin  // div 
                            reghi = val_rs % val_rt;
                            reglo = val_rs / val_rt;
                        end
                        6'b010000: write2reg(inst_rd, reghi);  // mfhi
                        6'b010010: write2reg(inst_rd, reglo);  // mflo
                    endcase
                end
                6'b000010: pc = {pc[31:28], inst_temp[25:0], 2'b00};  // j
                6'b000011: begin  // jal 
                    write2reg(31, pc);          
                    pc = {pc[31:28], inst_temp[25:0], 2'b00};        
                end
                6'b000100: begin  // beq 
                    if (val_rs == val_rt) pc = pc + (inst_imm_sext << 2);
                end
                6'b000101: begin  // bne 
                    if (val_rs != val_rt) pc = pc + (inst_imm_sext << 2);
                end
                6'b001000: write2reg(inst_rt, val_rs + inst_imm_sext);  // addi
                6'b001010: write2reg(inst_rt, val_rs < inst_imm_sext ? 1 : 0);  // slti 
                6'b001101: write2reg(inst_rt, val_rs | inst_imm_zext);  // ori
                6'b001110: write2reg(inst_rt, val_rs ^ inst_imm_zext);  // xori
                6'b100011: begin  // lw 
                    write2reg(inst_rt, data_in); // Reads from the external bus
                end
                6'b101011: begin  // sw 
                end
                6'b111111: begin // DROP_PRIV
                    if (mode_bit) mode_bit = 0;
                end
            endcase
        end
    endtask

    integer i;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            for (i = 0; i < 32; i = i + 1) begin
                regfile[i] = 0;
            end
            pc = 0;
            reghi = 0;
            reglo = 0;
            mode_bit = 1;
            // data_out = 0;
            // mem_read = 0;
            // mem_write = 0;
        end else begin
            exec_internal();
        end
    end
endmodule