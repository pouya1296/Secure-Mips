#!/usr/bin/env python3
"""
Script to concatenate all files in the current directory and subdirectories
into a single output file with file paths as headers.
"""

import os
import sys
from pathlib import Path

def should_ignore(path):
    """Check if the path should be ignored."""
    ignore_patterns = [
        '.git', '__pycache__', 'venv', 'env', 'node_modules',
        'dist', 'build', '.idea', '.vscode', '.pytest_cache',
        '.mypy_cache', '.tox', '.coverage', 'htmlcov',
        '*.pyc', '*.pyo', '*.pyd', '__pycache__', 'sepehr', 'hyperparameter', 'model', 'runner.sh',
        '.txt', 'build', 'script.py'
    ]
    
    path_str = str(path)
    
    # Check if path contains any ignore pattern
    for pattern in ignore_patterns:
        if pattern in path_str:
            return True
    
    return False

def should_include_file(file_path):
    """Check if the file should be included based on extension."""
    # You can customize this to include only specific file types
    # Or include all files (except binary files)
    text_extensions = {
        '.txt', '.py', '.js', '.html', '.css', '.json', '.xml', '.yaml', '.yml',
        '.sh', '.bash', '.zsh', '.fish', '.md', '.rst', '.ini', '.cfg', '.conf',
        '.c', '.cpp', '.h', '.hpp', '.java', '.go', '.rs', '.rb', '.php',
        '.sql', '.ts', '.jsx', '.tsx', '.vue', '.scss', '.sass', '.less'
    }
    
    # Include all files if you want, but skip binary files
    # Uncomment the following line to include ALL files:
    # return True
    
    # Or filter by extension
    ext = file_path.suffix.lower()
    return ext != ".jar"

def concatenate_files(output_file):
    """Concatenate all files in the current directory to the output file."""
    root_dir = Path.cwd()
    output_path = root_dir / output_file
    
    # Skip if output file already exists
    files_processed = 0
    
    try:
        with open(output_path, 'w', encoding='utf-8') as out_f:
            # Write header
            out_f.write("=" * 80 + "\n")
            out_f.write(f"CONCATENATED OUTPUT - Generated on: {__import__('datetime').datetime.now()}\n")
            out_f.write(f"Root Directory: {root_dir}\n")
            out_f.write("=" * 80 + "\n\n")
            
            # Walk through all files
            for root, dirs, files in os.walk(root_dir):
                # Remove ignored directories from the walk
                dirs[:] = [d for d in dirs if not should_ignore(Path(root) / d)]
                
                # Sort files for consistent output
                files.sort()
                
                for file in files:
                    file_path = Path(root) / file
                    
                    # Skip the output file itself
                    if file_path == output_path:
                        continue
                    
                    # Skip if the file should be ignored
                    if should_ignore(file_path):
                        continue
                    
                    # Skip binary files or files we don't want
                    if not should_include_file(file_path):
                        continue
                    
                    try:
                        # Get relative path from root directory
                        rel_path = file_path.relative_to(root_dir)
                        
                        # Read file content
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as in_f:
                            content = in_f.read()
                        
                        # Write file header
                        out_f.write("=" * 80 + "\n")
                        out_f.write(f"FILE: ./{rel_path}\n")
                        out_f.write(f"PATH: {file_path.absolute()}\n")
                        out_f.write(f"SIZE: {len(content)} bytes\n")
                        out_f.write("=" * 80 + "\n\n")
                        
                        # Write file content
                        out_f.write(content)
                        
                        # Add a blank line after each file
                        if not content.endswith('\n'):
                            out_f.write('\n')
                        out_f.write('\n')
                        
                        files_processed += 1
                        
                        # Print progress
                        if files_processed % 10 == 0:
                            print(f"Processed {files_processed} files...", end='\r')
                            
                    except Exception as e:
                        print(f"\nWarning: Could not read {file_path}: {e}")
                        out_f.write(f"[ERROR: Could not read file: {e}]\n\n")
                        continue
        
        print(f"\n\n✅ Successfully processed {files_processed} files")
        print(f"📄 Output saved to: {output_path}")
        
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)

def main():
    """Main entry point."""
    # Set output filename (you can change this)
    output_file = "concatenated_output.txt"
    
    # Check if output file already exists
    if Path(output_file).exists():
        response = input(f"⚠️  {output_file} already exists. Overwrite? (y/n): ")
        if response.lower() != 'y':
            print("Operation cancelled.")
            sys.exit(0)
    
    print(f"🚀 Starting file concatenation...")
    print(f"📂 Root directory: {Path.cwd()}")
    print(f"📝 Output file: {output_file}\n")
    
    concatenate_files(output_file)

if __name__ == "__main__":
    main()