module main (
    input wire clk,
    input wire rst
);

  
    wire [31:0] cpu_inst_addr, cpu_inst_in;
    wire [31:0] cpu_data_addr, cpu_data_out, cpu_data_in;
    wire cpu_mem_read, cpu_mem_write;
    wire mode_bit_wire;
    
  
    wire hash_write_en, hash_read_en;
    wire [31:0] hash_data_out;

  
    wire ram_write_en, ram_read_en, rom_read_en;
    wire [31:0] ram_data_in, ram_data_out, ram_inst_data_out, rom_data_out;


    wire watchdog_rst;

   
    CPU core (
        .clk(clk),
        .rst(watchdog_rst),      
        .inst_addr(cpu_inst_addr),
        .inst_in(cpu_inst_in),      
        .data_addr(cpu_data_addr),
        .data_out(cpu_data_out),
        .data_in(cpu_data_in),      
        .mem_read(cpu_mem_read),
        .mem_write(cpu_mem_write),
        .current_mode(mode_bit_wire)
    );


    Memory_Router router (
        .cpu_inst_addr(cpu_inst_addr),
        .cpu_inst_in(cpu_inst_in),
        
        .cpu_data_addr(cpu_data_addr),
        .cpu_data_out_to_mem(cpu_data_out),
        .cpu_mem_read(cpu_mem_read),
        .cpu_mem_write(cpu_mem_write),
        .cpu_data_in_from_mem(cpu_data_in),
        .mode_bit(mode_bit_wire),
        
        .hash_write_en(hash_write_en),
        .hash_read_en(hash_read_en),
        .hash_data_in(hash_data_out),
        
        .ram_write_en(ram_write_en),
        .ram_read_en(ram_read_en),
        .ram_data_in(ram_data_in),
        .ram_data_out(ram_data_out),
        .ram_inst_data_out(ram_inst_data_out),
        
        .rom_read_en(rom_read_en),
        .rom_data_out(rom_data_out)
    );


    Hash_Accelerator hasher (
        .clk(clk),
        .rst(watchdog_rst), 
        .data_in(cpu_data_out), 
        .write_en(hash_write_en), 
        .read_en(hash_read_en), 
        .data_out(hash_data_out)
    );


    Hardware_Execution_Watchdog watchdog_inst (
        .clk(clk),
        .rst_in(rst),              
        .mode_bit(mode_bit_wire),
        .pc(cpu_inst_addr), 
        .sys_rst_out(watchdog_rst) 
    );


    reg [31:0] boot_rom [0:1023];
    reg [31:0] user_ram [0:1023]; 


    assign rom_data_out = boot_rom[cpu_inst_addr >> 2];
    assign ram_data_out = user_ram[(cpu_data_addr - 32'h1000) >> 2];
    assign ram_inst_data_out = user_ram[(cpu_inst_addr - 32'h1000) >> 2];

    always @(posedge clk) begin
        if (ram_write_en) begin
            user_ram[(cpu_data_addr - 32'h1000) >> 2] <= ram_data_in;
        end
    end

endmodule