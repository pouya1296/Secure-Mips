import sys
import re

# --- Instruction Set Architecture Definitions ---
R_TYPE_OPCODE = 0x00
OPCODES = {
    'addi': 0x08,
    'ori':  0x0D,
    'xori': 0x0E,
    'lw':   0x23,
    'sw':   0x2B,
    'beq':  0x04,
    'bne':  0x05,
    'j':    0x02,
}

FUNCT_CODES = {
    'add': 0x20,
    'sub': 0x22,
    'and': 0x24,
    'or':  0x25,
    'xor': 0x26,
    'slt': 0x2A,
}

# Standard MIPS register mapping (used in your bootloader)
REGISTERS = {
    '$zero': 0, '$0': 0,
    '$t0': 8, '$t1': 9, '$t2': 10, '$t3': 11, '$t4': 12, '$t5': 13, '$t6': 14, '$t7': 15,
    '$s0': 16, '$s1': 17, '$s2': 18, '$s3': 19, '$s4': 20, '$s5': 21, '$s6': 22, '$s7': 23,
}

# Custom Instruction
CUSTOM_INSTRUCTIONS = {
    'DROP_PRIV': 0xFC000000  # Custom opcode 111111 with all other bits as 0
}

def parse_register(reg_str):
    reg_str = reg_str.replace(',', '').strip()
    if reg_str not in REGISTERS:
        raise ValueError(f"Unknown register: {reg_str}")
    return REGISTERS[reg_str]

def parse_immediate(imm_str):
    imm_str = imm_str.replace(',', '').strip()
    if imm_str.startswith('0x'):
        return int(imm_str, 16)
    return int(imm_str)

def assemble_file(input_file, output_file):
    with open(input_file, 'r') as f:
        lines = f.readlines()

    # Pass 1: Remove comments, empty lines, and map labels to addresses
    clean_lines = []
    labels = {}
    current_address = 0x0000

    for line in lines:
        line = line.split('#')[0].strip() # Strip comments
        if not line or line.startswith('.'): # Skip empty lines and directives like .text
            continue
        
        # Check if line is a label
        if line.endswith(':'):
            label_name = line[:-1].strip()
            labels[label_name] = current_address
        else:
            clean_lines.append((current_address, line))
            current_address += 4

    machine_code_output = []

    # Pass 2: Translate instructions to machine code
    for pc, line in clean_lines:
        parts = line.replace(',', ' ').split()
        instr = parts[0]

        machine_code = 0x00000000

        # Custom Instructions
        if instr == 'DROP_PRIV':
            machine_code = CUSTOM_INSTRUCTIONS['DROP_PRIV']

        # R-Type Instructions
        elif instr in FUNCT_CODES:
            rs = parse_register(parts[2])
            rt = parse_register(parts[3])
            rd = parse_register(parts[1])
            funct = FUNCT_CODES[instr]
            machine_code = (R_TYPE_OPCODE << 26) | (rs << 21) | (rt << 16) | (rd << 11) | funct

        # I-Type Instructions (Arithmetic/Logic)
        elif instr in ['addi', 'ori', 'xori']:
            rs = parse_register(parts[2])
            rt = parse_register(parts[1])
            imm = parse_immediate(parts[3]) & 0xFFFF # Mask to 16 bits
            opcode = OPCODES[instr]
            machine_code = (opcode << 26) | (rs << 21) | (rt << 16) | imm

        # I-Type Instructions (Memory)
        elif instr in ['lw', 'sw']:
            rt = parse_register(parts[1])
            # Parse offset(rs), e.g., 0($s0)
            mem_match = re.match(r"(-?(?:0x)?[0-9a-fA-F]+)\((\$\w+)\)", parts[2])
            if mem_match:
                imm = parse_immediate(mem_match.group(1)) & 0xFFFF
                rs = parse_register(mem_match.group(2))
            else:
                raise ValueError(f"Invalid memory syntax: {line}")
            
            opcode = OPCODES[instr]
            machine_code = (opcode << 26) | (rs << 21) | (rt << 16) | imm
            
        # SLL Instruction (R-Type but uses shift amount instead of rs)
        elif instr == "sll":
            rd = parse_register(parts[1])
            rt = parse_register(parts[2])
            shamt = parse_immediate(parts[3]) & 0x1F # 5-bit shift amount
            funct = 0x00
            # sll: opcode=0, rs=0, rt, rd, shamt, funct=0
            machine_code = (R_TYPE_OPCODE << 26) | (0 << 21) | (rt << 16) | (rd << 11) | (shamt << 6) | funct
            
        # Branch Instructions
        elif instr in ['beq', 'bne']:
            rs = parse_register(parts[1])
            rt = parse_register(parts[2])
            target = parts[3]
            
            if target in labels:
                target_addr = labels[target]
                # Branch offset calculation (PC-relative)
                offset = ((target_addr - pc - 4) // 4) & 0xFFFF
            else:
                raise ValueError(f"Unknown label: {target}")

            opcode = OPCODES[instr]
            machine_code = (opcode << 26) | (rs << 21) | (rt << 16) | offset

        # J-Type Instructions
        elif instr == 'j':
            target = parts[1]
            if target in labels:
                target_addr = labels[target]
            else:
                target_addr = parse_immediate(target)
            
            # Jump address is calculated by dividing absolute address by 4
            jump_addr = (target_addr // 4) & 0x3FFFFFF
            opcode = OPCODES[instr]
            machine_code = (opcode << 26) | jump_addr

        else:
            raise ValueError(f"Unsupported instruction: {instr}")

        # Format as an 8-character hex string (zero-padded)
        hex_string = f"{machine_code:08x}"
        machine_code_output.append(hex_string)

    # Write out the results
    with open(output_file, 'w') as f:
        lines_written = 0
        # Iterate over the output list we generated, NOT the last machine_code integer
        for hex_str in machine_code_output:
            f.write(hex_str + '\n')
            lines_written += 1
            
        # Add this padding loop to silence Iverilog warnings
        while lines_written < 1024:
            f.write("00000000\n")
            lines_written += 1
            
    print(f"Assembly successful! Wrote {len(machine_code_output)} instructions to {output_file}.")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python assembler.py <input.s> <output.hex>")
    else:
        assemble_file(sys.argv[1], sys.argv[2])