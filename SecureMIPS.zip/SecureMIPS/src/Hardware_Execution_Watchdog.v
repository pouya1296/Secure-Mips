module Hardware_Execution_Watchdog (
    input wire clk,
    input wire rst_in,
    input wire mode_bit,
    input wire [31:0] pc,
    output reg sys_rst_out
);

    wire is_in_ram = (pc >= 32'h00001000) && (pc <= 32'h00001FFF);

    wire watchdog_trigger = (mode_bit == 1'b1) && is_in_ram;

    assign sys_rst_out = rst_in | watchdog_trigger;

endmodule